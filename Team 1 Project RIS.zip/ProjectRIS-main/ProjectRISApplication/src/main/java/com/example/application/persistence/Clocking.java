package com.example.application.persistence;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "clocking")
public class Clocking {
    @Id
    @Column(name = "clocking_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long clocking_id;
    @Column(name = "patient_id")
    public Long patient_id;
    @Column(name = "start_time")
    public Date start_datetime;
    @Column(name = "end_time")
    public Date end_datetime;
    @Column(name = "tech_id")
    public Long tech_id;

    @Transient
    private Patient patientObject;
    @Transient
    private User technicianObject;

    @Transient
    public String date;
    @Transient
    public String start_time;
    @Transient
    public String end_time;

    // GETTERS
    public Long getId() {
        return this.clocking_id;
    }

    public Long getTech_id() {
        return this.tech_id;
    }

    public Long getPatient_id() {
        return this.patient_id;
    }

    public String getDate() {
        return this.date;
    }

    public Date getStart_datetime() {
        return this.start_datetime;
    }

    public String getStart_time() {
        return this.start_time;
    }

    public Date getEnd_datetime() {
        return this.end_datetime;
    }

    public String getEnd_time() {
        return this.end_time;
    }

    public Patient getPatientObject() {
        return this.patientObject;
    }

    public User getTechnicianObject() {
        return this.technicianObject;
        // SETTERS
    }

    public void setTech_id(Long tech_id) {
        this.tech_id = tech_id;
    }

    public void setPatient_id(Long patient_id) {
        this.patient_id = patient_id;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public void setStart_datetime(Date start_time) {
        this.start_datetime = start_time;
    }

    public void setStart_time(String start_time) {
        this.start_time = start_time;
    }

    public void setEnd_datetime(Date end_time) {
        this.end_datetime = end_time;
    }

    public void setEnd_time(String end_time) {
        this.end_time = end_time;
    }

    public void setPatientObject(Patient patientObject) {
        this.patientObject = patientObject;
    }

    public void setTechnicianObject(User technicianObject) {
        this.technicianObject = technicianObject;
    }
}