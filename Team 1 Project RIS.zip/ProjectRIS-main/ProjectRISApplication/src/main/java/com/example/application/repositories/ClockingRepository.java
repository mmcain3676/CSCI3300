package com.example.application.repositories;
import com.example.application.persistence.Clocking;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.transaction.annotation.Transactional;

public interface ClockingRepository extends CrudRepository<Clocking, Long> {
    
    @Modifying
    @Query(value = "UPDATE clocking SET checked_in = 1 WHERE appointment_id = ?1", nativeQuery = true)
    @Transactional(rollbackFor = Exception.class)
    int setStatusForClocking(Long status, Long id);
        
    @Modifying
    @Query(value = "UPDATE clocking SET closed = 1 WHERE appointment_id = ?1", nativeQuery = true)
    @Transactional(rollbackFor = Exception.class)
    int setAppointmentForClocking(Long appointment, Long id);
}